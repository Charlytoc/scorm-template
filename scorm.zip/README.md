# Proyecto de Demostración de eLearning SCORM

Este es un proyecto de demostración que presenta el producto mínimo viable (MVP) para un proyecto de eLearning SCORM.

## Instrucciones

Para generar el archivo ZIP que se subirá a SCORM Cloud, sigue estos pasos:

1. Abre una terminal en el directorio raíz del repositorio.
2. Ejecuta el siguiente comando:

```bash
make zip
```

Ese archivo zip contiene los recursos que se necesita para interactuar con el LMS.
